package TestNG;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class AddSauTestng {
	
	WebDriver dr;
	AddSaujava Aobj;
	int c=0;
	int[] pn={3,5};
	
	@BeforeClass
	public void before_class()
	{
        System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		
		dr = new ChromeDriver();
		dr.get("https://www.saucedemo.com/");
		dr.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		Aobj = new AddSaujava(dr);			
		Aobj.SauLog("standard_user","secret_sauce");
	}
	
	@BeforeMethod
	public void Sbefore_method()
	{
		Aobj.add_product(pn[c]);
		c++;
		System.out.println("In cart");
	}
	
	 @AfterMethod
	  public void Saftermethod()
	  { 
		  if(c<2)
		  {
		  Aobj.Cont_Shop();
		  }
	  }
	
  @Test
  public void T1()
  {
	  Aobj.verify();
//	  SoftAssert sa = new SoftAssert();
//	  sa.assertEquals(Aobj.itemN, Aobj.AitemN );
//	  sa.assertEquals(Aobj.itemP, Aobj.exP);
//	  sa.assertAll();
	  
	 
  }
  
  @Test
  public void T2() 
  {
	  Aobj.verify();
//	  SoftAssert sa = new SoftAssert();
//	  sa.assertEquals(Aobj.itemN, Aobj.AitemN );
//	  sa.assertEquals(Aobj.itemP, Aobj.exP);
//	  sa.assertAll();
  }
  
  @AfterClass
  public void Safterclass()
  {
	  Aobj.add_info();
	  //System.out.println("Info added");
	  dr.close();
  }
   
		
}
