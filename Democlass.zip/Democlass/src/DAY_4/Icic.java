package DAY_4;

public class Icic extends Bank {
	public float get_roi()
	{
	return 6.5f;	
	}
}
