package DAY_3;

public class calc {
public int add(int x ,int y)
{
	int z;
	z=x+y;
	return z;
}
}
