package TestNG2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class BClogin  {
	
	BCjava obj;
	WebDriver dr;
	int[] i ={1,2};
	int c=0;
  @Test
  public void first() {
	  
	  //obj.compare();
	  SoftAssert sa = new SoftAssert();
	  sa.assertEquals(obj.exp_name, obj.act_name);
	  sa.assertEquals(obj.exp_price, obj.act_price);
	  sa.assertAll();
    
  }
  @Test
  public void Second() {
	  
	  //obj.compare();
	  SoftAssert sa = new SoftAssert();
	  sa.assertEquals(obj.exp_name, obj.act_name );
	  sa.assertEquals(obj.exp_price, obj.act_price);
	  sa.assertAll();
	  
     
  }
  
  @BeforeMethod
  public void beforeMethod() {
	  obj.AddProduct(i[c]);
	  c++;
  }

  @AfterMethod
  public void afterMethod() {
	  if(c<2)
	  {
	  obj.Continue();
	 
	  }
  }

  @BeforeClass
  public void beforeClass()
  {
	  System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
	  dr=new ChromeDriver();
	  dr.get("https://www.saucedemo.com/");
	  obj=new BCjava(dr);
	  obj.LoginMethod();
	  }

  @AfterClass
  public void afterClass()
  {
	  
	  obj.AddInfo();
	  obj.thankYouMsg();
	  dr.close();
  }

}
