package Testng_DataD;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class dataprovider_basic {
	
  @Test(dataProvider="login_data")
  public void login(String eid, String pwd, String exp_res)
  {
	  System.out.println("email id : " +eid+ "pwd : "+pwd+ "expected res :" +exp_res);
  }
  @DataProvider(name="login_data")
  public String[][] provider_data()
  {
	  String[][] data= {
			              {"e1","p1","er1"},
			              {"e2","p2","er2"},
			              {"e3","p3","er3"}
	                    };  
			  return data;
	}
}
