package DAY_1;

public class Program19 {
	
	public static void main(String []args){
	int i,n=11;

	for (i = 2; i<= n/2; i++)
    {
	if(n%i == 0)
	{
	System.out.println(" not a prime");
	break;
	}
	
}
	if((n%i)!=0)
	System.out.println("prime");
}
}