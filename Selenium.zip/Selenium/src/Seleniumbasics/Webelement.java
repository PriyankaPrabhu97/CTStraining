package Seleniumbasics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Webelement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		WebDriver dr= new ChromeDriver();
		
	    dr.get("http://demowebshop.tricentis.com");
	    
	    dr.findElement(By.linkText("Log in")).click();
	    dr.findElement(By.id("Email")).sendKeys("priyankaprabhu25@gmail.com");
	    dr.findElement(By.id("Password")).sendKeys("9110826984");
	    dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	    
	    String s = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).getText();
	    String k="priyankaprabhu25@gmail.com";
	    
	    int m = k.compareTo(s);
	    if(m==0)
	    {
	    	System.out.println("Fail");
	    }
	    else
	    {
	    	System.out.println("Pass");
	    }
	}

}
