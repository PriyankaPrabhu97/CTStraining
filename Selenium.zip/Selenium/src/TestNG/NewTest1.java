package TestNG;

import org.testng.annotations.Test;

public class NewTest1 {
	
  @Test(priority=1)
  public void a()
  {
	  System.out.println("Testing t1");
  }
  
  @Test(priority=10)
  public void p()
  {
	  System.out.println("Testing t2");
  }
  
  @Test(priority=5)
  public void t()
  {
	  System.out.println("Testing t3");
  }
}
