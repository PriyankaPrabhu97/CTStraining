package N_pages;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import N_library.Utilities;

public class pet_home {
	
	WebDriver dr;	
	Utilities wt;
	
	public pet_home(WebDriver dr)
	{
		this.dr=dr;
		wt= new Utilities(dr);
	}
		
	public void sign()
	{					
	 By by_sign_in = By.xpath("//div[@id='MenuContent']/a[2]");
	 WebElement we_sign_in=wt.waitForElement(by_sign_in,20);
	 we_sign_in.click();	
	 
	 //wt.getScreenshot();
	}
	
	public String get_title()
	{
		return dr.getTitle();
	}

}
