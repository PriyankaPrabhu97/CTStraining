package TestNG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LogJava {
	
	WebDriver dr;
	
	public void JLog(String eid, String pwd)
	{
		dr.findElement(By.xpath("//input[@type='text']")).sendKeys(eid);
		dr.findElement(By.xpath("//input[@type='password']")).sendKeys(pwd);
		dr.findElement(By.xpath("//input[@type='submit']")).click();
	}
	
	public LogJava(WebDriver dr)
	{
		this.dr=dr;
	}

}
