package N_pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import N_library.Utilities;

public class pet_home2 {
	
	WebDriver dr;
	Utilities wt;
	
	public pet_home2(WebDriver dr)
	{this.dr=dr;}
		
	public void Userid(String uid)
	{
	By user_id = By.xpath("//form[@action='/accounts/create']/table//child::tr[1]//child::td[2]/input");
	WebElement we_eid = wt.waitForElement(user_id, 20);
	we_eid.sendKeys(uid);
	}
	
	public void NewPwd(String Npwd)
	{
	By newpass = By.xpath("//form[@action='/accounts/create']/table//child::tr[2]//child::td[2]/input");
	WebElement we_newpass = wt.waitForElement(newpass, 20);
	we_newpass.sendKeys(Npwd);
	}
	
	public void RePwd(String Rpwd)
	{
	By re_pass = By.xpath("//form[@action='/accounts/create']/table//child::tr[3]//child::td[2]/input");
	WebElement we_re_pass = wt.waitForElement(re_pass, 20);
	we_re_pass.sendKeys(Rpwd);
	}
	
	public void FirstName(String Fname)
	{
	By firstName = By.xpath("//form[@action='/accounts/create']/div//child::table[1]//child::tr[1]/td[2]/input");
	WebElement we_firstname = wt.waitForElement(firstName, 20);
	we_firstname.sendKeys(Fname);
	}
	
	public void LastName(String Lname)
	{
	By lastName = By.xpath("//form[@action='/accounts/create']/div//child::table[1]//child::tr[2]/td[2]/input");
	WebElement we_lastname = wt.waitForElement(lastName, 20);
	we_lastname.sendKeys(Lname);
	}
	
	public void Email(String eid)
	{
	By email = By.xpath("//form[@action='/accounts/create']/div//child::table[1]//child::tr[3]/td[2]/input");
	WebElement we_email = wt.waitForElement(email, 20);
	we_email.sendKeys(eid);
	}
	
	public void Phone(String num)
	{
	By phone = By.xpath("//form[@action='/accounts/create']/div//child::table[1]//child::tr[4]/td[2]/input");
	WebElement we_phone = wt.waitForElement(phone, 20);
	we_phone.sendKeys(num);
	}
	
	public void Address1(String add1)
	{
	By address1 = By.xpath("//form[@action='/accounts/create']/div//child::table[1]//child::tr[5]/td[2]/input");
	WebElement we_address1 = wt.waitForElement(address1, 20);
	we_address1.sendKeys(add1);
	}
	
	public void Address2(String add2)
	{
	By address2 = By.xpath("//form[@action='/accounts/create']/div//child::table[1]//child::tr[6]/td[2]/input");
	WebElement we_address2 = wt.waitForElement(address2, 20);
	we_address2.sendKeys(add2);
	}
	
	public void city(String cty)
	{
	By city = By.xpath("//form[@action='/accounts/create']/div//child::table[1]//child::tr[7]/td[2]/input");
	WebElement we_city = wt.waitForElement(city, 20);
	we_city.sendKeys(cty);
	}
	
	public void State(String sta)
	{
	By state = By.xpath("//form[@action='/accounts/create']/div//child::table[1]//child::tr[8]/td[2]/input");
	WebElement we_state = wt.waitForElement(state, 20);
	we_state.sendKeys(sta);
	}
	
	public void Zip(String zip1)
	{
	By zip = By.xpath("//form[@action='/accounts/create']/div//child::table[1]//child::tr[9]/td[2]/input");
	WebElement we_zip = wt.waitForElement(zip, 20);
	we_zip.sendKeys(zip1);
	}
	
	public void Country(String ctry)
	{
	By country = By.xpath("//form[@action='/accounts/create']/div//child::table[1]//child::tr[10]/td[2]/input");
	WebElement we_country = wt.waitForElement(country, 20);
	we_country.sendKeys(ctry);
	}
	
	public void click1()
	{
	By lan = By.xpath("//form[@action='/accounts/create']//table[2]//tr[1]//child::td[2]//select");
	WebElement we_lan = wt.waitForElement(lan, 20);
	we_lan.click();
	}
	
	public void click2()
	{
	By fav = By.xpath("//form[@action='/accounts/create']//table[2]//child::tr[2]/td[2]//select//optin[5]");
	WebElement we_fav = wt.waitForElement(fav, 20);
	we_fav.click();
	}
	
	public void click3()
	{
	By mlist = By.xpath("//form[@action='/accounts/create']//table[2]//child::tr[3]/td[2]input[1]");
	WebElement we_mlist = wt.waitForElement(mlist, 20);
	we_mlist.click();
	}
	
	public void click4()
	{
	By mban = By.xpath("//form[@action='/accounts/create']//table[2]//child::tr[3]/td[2]input[1]");
	WebElement we_mban = wt.waitForElement(mban, 20);
	we_mban.click();
	}
	
	public void click5()
	{
	By s_btn = By.xpath("//input[@id='save']");
	WebElement we_s_btn = wt.waitForElement(s_btn, 20);
	we_s_btn.click();
	}	
	
	public void do_reg(String u, String p1, String p2, String fn, String ln, String e, String num, String a1, String a2, String ct, String sa, String cy, String zp ) 
	{
		this.Userid(u);
		this.NewPwd(p1);
		this.RePwd(p2);
		this.FirstName(fn);
		this.LastName(ln);
		this.Email(e);
		this.Phone(num);
		this.Address1(a1);
		this.Address2(a2);
		this.State(sa);
		this.Zip(zp);
		this.city(ct);
		this.Country(cy);
		this.click1();
		this.click2();
		this.click3();
		this.click4();
		this.click5();
	}
	
	
	
	

}
