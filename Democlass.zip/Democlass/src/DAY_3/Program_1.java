package DAY_3;

import java.util.Scanner;

public class Program_1 {
	public static void main(String[] args) {
Scanner input =new Scanner(System.in);
System.out.println("enter the characters");
int count=0;
char c;
c=0;
while(c!='n')
{
	c=input.next().charAt(0);
	if(c=='a' || c=='e' || c=='i' || c=='o' || c=='u')
	{
		count++;
	}
}
	System.out.println("the number of vowels present are "+(count));
}
}