package DAY_5;

public class Test_interface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Drawable d= new Rectangle();
d.draw();

	}

}
