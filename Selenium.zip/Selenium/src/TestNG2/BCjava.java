package TestNG2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class BCjava  {
	WebDriver dr;
	String  exp_name,act_name,act_price,exp_price;
	int count=0;

	public BCjava(WebDriver dr)
	{
		this.dr=dr;
	}

	public void LoginMethod()
	{
		dr.findElement(By.xpath("//input[@type='text']")).sendKeys("standard_user");
		dr.findElement(By.xpath("//input[@type='password']")).sendKeys("secret_sauce");
		dr.findElement(By.xpath("//input[@type='submit']")).click();
	}
	public void AddProduct(int i)
	{
		
		
		dr.findElement(By.xpath("//div[@class='inventory_item']["+i+"]//child::button")).click();
		count++;
		System.out.println(count);
		exp_name=dr.findElement(By.xpath("//div[@class='inventory_item']["+i+"]//div[2]//div")).getText();
		String Strexp_price=dr.findElement(By.xpath("//div[@class='inventory_item']["+i+"]//div[3]")).getText();
		exp_price =Strexp_price.substring(1);
		dr.findElement(By.xpath("//div[@id='shopping_cart_container']")).click();
		act_name=dr.findElement(By.xpath("//div[@class='cart_item']["+count+"]//div[2]//div")).getText();
		act_price=dr.findElement(By.xpath("//div[@class='cart_item']["+count+"]//div[2]//div[2]")).getText();
		
	}
//	public void compare()
//	{
//	      if((exp_name.equalsIgnoreCase(act_name))&&(exp_price.equalsIgnoreCase(act_price)))
//	      {
//	    	  
//			System.out.println("Pass");
//	      }
//	      else
//	    	 System.out.println("Fail");
//	}
	public void AddInfo()
	{

		  dr.findElement(By.xpath("//a[text()='CHECKOUT']")).click();
		  dr.findElement(By.xpath("//input[@id='first-name']")).sendKeys("Priya");
		  dr.findElement(By.xpath("//input[@id='last-name']")).sendKeys("CKM"); 
		  dr.findElement(By.xpath("//input[@id='postal-code']")).sendKeys("Samantha nagar");
		  dr.findElement(By.xpath("//input[@type='submit']")).click();
		  dr.findElement(By.xpath("//a[@class='btn_action cart_button']")).click();
	}
	public void thankYouMsg(){
		String msg = dr.findElement(By.xpath("//h2[contains(text(),'THANK YOU')]")).getText();
		System.out.println(msg);
	}
	public void Continue(){
		
		dr.findElement(By.xpath("//a[text()='Continue Shopping']")).click();
	
	}


}
