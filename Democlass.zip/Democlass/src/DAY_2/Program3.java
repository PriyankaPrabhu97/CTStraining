package DAY_2;

public class Program3 {
	public static void main(String[] args)
	{
		int[][] m={{75,32,45},{32,45,45},{52,52,54},{2,5,4}};
		int sum=0;
		for(int i=0;i<=3;i++)
		{
			for(int j=0;j<=2;j++)
			{
				if(m[i][j]%2==0)
				{
					sum+=m[i][j];
				}
			}
		}
		System.out.println(sum);
	}
}
