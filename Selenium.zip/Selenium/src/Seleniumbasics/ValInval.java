package Seleniumbasics;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ValInval {
	
	public String Readexl(String filename, String sheetname, int r, int c){
		String s=null;
		File f = new File(filename);
		try {
			
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sheet = wb.getSheet(sheetname);
			XSSFRow R = sheet.getRow(r);
			XSSFCell C = R.getCell(c);
			s=C.getStringCellValue();
				
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return s;
	}
	
	public String Writeexl(String FN,String SN, int row, int cell, String ip){
       String sr = null;
       File f = new File(FN);
		try {
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sheet = wb.getSheet(SN);
			XSSFRow Row = sheet.getRow(row);
			
			XSSFCell Cell=Row.createCell(cell);                     
			Cell = Row.getCell(cell);
			
			
			Cell.setCellValue(ip);
			FileOutputStream fos = new FileOutputStream(f);
			wb.write(fos);
		
		
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		return sr;
	}
	
	public String Login(String eid,String pwd)
	{
		String AclR = null;
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		WebDriver dr = new ChromeDriver();
		
		dr.get("http://demowebshop.tricentis.com");
		dr.findElement(By.linkText("Log in")).click();
		dr.findElement(By.id("Email")).sendKeys(eid);
		dr.findElement(By.id("Password")).sendKeys(pwd);
		dr.findElement(By.xpath("//input[@value='Log in']")).click();
		
		try{
		 AclR = dr.findElement(By.xpath("//span[@class='field-validation-error']")).getText();
		}
		catch( org.openqa.selenium.NoSuchElementException ee){
		try
		{
		 AclR = dr.findElement(By.xpath("//div[@class='validation-summary-errors']")).getText();
		}
		catch( org.openqa.selenium.NoSuchElementException e)
		{
	     AclR = dr.findElement(By.xpath("//div[@class='header-links']//child::a")).getText();
		}
	}
		dr.close();
		return AclR;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  ValInval L= new ValInval();
	      String FNL="C:\\Users\\BLTuser.BLT235\\Desktop\\Excel\\ValInval.xlsx",
	    		 SNL="Sheet1";
	      for(int r=1;r<=5;r++)
	      {
	      String E = L.Readexl(FNL,SNL,r,0);
	      if(E.compareTo("Blank")==0)
	    	  E=" ";
	      System.out.println(E);
	      String P = L.Readexl(FNL,SNL,r,1);
	      if(P.compareTo("Blank")==0)
	    	  P=" ";
	      System.out.println(P);
	       
	      String Res = L.Readexl(FNL,SNL,r,2);
	      System.out.println(Res);
	      
	      String AV=L.Login(E, P);
	      System.out.println(AV);
	      
	      String Ex = L.Writeexl(FNL,SNL,r,3,AV);
	      
	      String Result;
	      if(AV.equals(Res)==true)
	      {
	    	  Result="Pass";
	      }  
	      else
	      {
	    	  Result="Fail";
	      }
	      
	      String Ax = L.Writeexl(FNL,SNL,r,4,Result);
	      System.out.println(Result);
		}

	}

}
