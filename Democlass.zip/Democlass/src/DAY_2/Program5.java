package DAY_2;
public class Program5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="I love Bangalore more than chennai",s2;
		int i=0,p=0;
		while(p<s1.length())
		{
			p=s1.indexOf(" ",i);
			if(p==-1)
			p=s1.length();
			s2=s1.substring(i,p);
			System.out.println(s2);
			
			i=p+1;
			
			
		}
	}
}

