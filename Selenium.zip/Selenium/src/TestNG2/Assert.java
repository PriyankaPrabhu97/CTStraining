package TestNG2;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Assert {
  @Test
  public void t1() 
  {
	  String er = "chennai" , ar = "chennai";
	  System.out.println("In test method t1");
	  SoftAssert sa = new SoftAssert();
	  sa.assertEquals(er, ar);
	  sa.assertAll();
  }
  
@Test
  public void t2()
  {
	  String er="chennai" , ar="chennai1";
	  System.out.println("In method t2");
	  SoftAssert sa = new SoftAssert();
	  sa.assertEquals(er, ar);
	  sa.assertAll();
	  
  }
}
