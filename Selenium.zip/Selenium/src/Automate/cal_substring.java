package Automate;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class cal_substring {
	

	static WebDriver dr;

	public String readexcel(String filename,String shtname,int r,int c)
	{
	String s = null;
	File f =new File(filename);
	try {
	FileInputStream fis= new FileInputStream(f);
	XSSFWorkbook wb=new XSSFWorkbook(fis);
	XSSFSheet sh=wb.getSheet(shtname);
	XSSFRow row=sh.getRow(r);
	XSSFCell cell=row.getCell(c);
	s=cell.getStringCellValue();

	} catch (FileNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	}

	return s;
	}

	public String date(String rd)
	{
	String only_date=rd.substring(0,2);
	System.out.println(only_date);
	return only_date;
	}

	public String month_year(String rd1)
	{
	String only_month=rd1.substring(3,8);
	System.out.println(only_month);

	String only_year=rd1.substring(9,rd1.length());
	System.out.println(only_year);

	String act_mon_year= only_month+" "+only_year;
	System.out.println(act_mon_year);

	return act_mon_year;
	}

	public void click_month_year(String mth_yr)

	{

	dr.findElement(By.xpath("//input[@type='text']")).click();

	String cur_month_year = dr.findElement(By.xpath("//div[@class='ui-datepicker-title']")).getText();

	while(!mth_yr.equals(cur_month_year))
	{
	dr.findElement(By.xpath("//span[@class='ui-icon ui-icon-circle-triangle-e']")).click();
	cur_month_year = dr.findElement(By.xpath("//div[@class='ui-datepicker-title']")).getText();
	}

	}

	public void click_date(String date)
	{
	List<WebElement>  all_dates=dr.findElements(By.xpath("//table[@class='ui-datepicker-calendar']//td"));

	for(WebElement ele:all_dates)
	{
	String check_date1=ele.getText();

	if(check_date1.equalsIgnoreCase(date))
	{
	ele.click();
	}

	}

	}


	public static void main(String[] args)

	{

	System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
	dr=new ChromeDriver();
	dr.get("http://seleniumpractise.blogspot.com/2016/08/how-to-handle-calendar-in-selenium.html");
	cal_substring obj=new cal_substring();
	String data=obj.readexcel("C:\\Users\\BLTuser.BLT0203\\Desktop\\pcts\\p1\\calender_date.xlsx", "sheet1", 0, 0);
	System.out.println(data);
	String m_y=data.substring(1,data.length()-1);
	System.out.println(m_y);
	String a_date=obj.date(m_y);
	String m_yr=obj.month_year(m_y);
	obj.click_month_year(m_yr);
	obj.click_date(a_date);

	}

}
