package Library;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Utilities {

	WebDriver dr;
	public Utilities(WebDriver dr)
	{
		this.dr = dr;
	}
	
	public WebDriver LaunchBrowser(String browser, String url)
	{
		switch(browser)
		{
		case "CHROME":
			System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
			dr = new ChromeDriver();
			break;
			
		case "FIREFOX":
			System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
			dr = new FirefoxDriver();
			break;
			
		default:
			System.out.println("Supported browser");
			break;
			
		}
		
		dr.get(url);
		dr.manage().window().maximize();
		dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		return dr;		
	}
	
	
}
