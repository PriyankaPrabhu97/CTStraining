package DAY_1;

public class program14 {

	public static void main(String[] args) {
		int i=5,k,m=4;
for(k=0;k<=4;k++)
{
	System.out.println(i+" * "+m+"= "+(i*m));
	i+=1;
	m+=2;

	
}

	}

}
