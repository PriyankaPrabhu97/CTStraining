package DAY_1;

public class Program9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int i,rem;
for(i=0;i<=10;i++)
{
	rem=i%2;
	if(rem==0)
		System.out.println(i);
	
}
	}

}
