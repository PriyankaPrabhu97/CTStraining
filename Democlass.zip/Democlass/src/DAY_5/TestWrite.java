package DAY_5;

public class TestWrite {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WritingXLFile obj =new WritingXLFile();
		obj.WriteExcel("C:\\Users\\BLTuser.BLT0215\\Documents\\Excel\\1.xlsx","Sheet1", 0, 0,"Hello");

	}

}
