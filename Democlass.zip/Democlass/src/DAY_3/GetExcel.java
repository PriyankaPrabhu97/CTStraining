package DAY_3;

import java.io.*;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class GetExcel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 File f= new File("C:\\Users\\BLTuser.BLT0215\\Documents\\Excel\\SurfExcel.xlsx");
 try {
	FileInputStream fis= new FileInputStream(f);
	XSSFWorkbook wb= new XSSFWorkbook(fis);
	XSSFSheet Sheet = wb.getSheet("Sheet1");
	XSSFRow Row=Sheet.getRow(0);
	XSSFCell Cell=Row.getCell(0);
	String s=Cell.getStringCellValue();
	System.out.println(s);
	XSSFSheet Sheet2 = wb.getSheet("Sheet2");
	XSSFRow Row2=Sheet2.getRow(0);
	XSSFCell Cell2=Row2.getCell(0);
	String s2=Cell2.getStringCellValue();
	System.out.println(s2);
	
	Cell2.setCellValue(s);
	FileOutputStream fos =new FileOutputStream(f);
	wb.write(fos);
}
 catch (FileNotFoundException e)
 {
	
	e.printStackTrace();
} catch (IOException e) {
	
	e.printStackTrace();
}
 
	}

}
