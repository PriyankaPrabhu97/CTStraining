package DAY_1;

public class Program5 {

	public static void main(String[] args) {
	int a=10,b=20,c=5;
	if((a<b)&&(a<c))
	{
		System.out.println("smallest number is" +a);
	}
	
	else if(b<c)
		System.out.println("smallest is " +b);
	else
		System.out.println("smallest is "+c);

}
}
