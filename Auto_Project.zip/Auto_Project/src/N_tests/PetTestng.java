package N_tests;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import N_library.Utilities;
import N_pages.pet_home;
import N_pages.pet_home1;
import N_pages.pet_home2;

public class PetTestng {
	
	WebDriver dr;
	Utilities ut;
	pet_home ph;
	pet_home1 ph1;
	pet_home2 ph2;
	
	String url="http://jpetstore.cfapps.io/catalog";
	
	@BeforeClass
	public void launchBrowser()
	{
		ut = new Utilities(dr);
	    dr=ut.launchbrowser("CHROME", url);
	    System.out.println("Done");		
	}
	
	@Test
	public void f1()
	{
		ph = new pet_home(dr);
		ph.sign();
		String hometitle = ph.get_title();
		Assert.assertTrue(hometitle.contains("JPet"));
	}
	
	
  @Test
  public void f2() {
	  ph1 = new pet_home1(dr);
	  ph1.login("Priyanka", "priyanka97");
	  //ph1.sign_in();
	  String rTitle = ph1.get_title();
	  Assert.assertTrue(rTitle.contains("JPet"));	  
  }
	
	
//  @Test
//  public void f3() {
//	  ph2 = new pet_home2(dr);
//	  ph2.do_reg("priyanka", "priyanka97", "priyanka97", "priyanka", "prabhu", "piya@gmail.com", "123456789", "chennai", "india", "ckm", "TN", "India", "123456");
//	  
//  }
}
