package DAY_4;

public class Bank
{
	float z;
public float get_roi()
{
return 0f;	
}
public void show()
{
	System.out.println("Bank Details: ");
}
}
