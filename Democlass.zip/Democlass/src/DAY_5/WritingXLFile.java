package DAY_5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbookType;

public class WritingXLFile {
	

	public void WriteExcel(String FileName,String Sheet,int Row,int Cell,String Str)
	{
		File f=new File(FileName);
		try {
			FileInputStream fis =new FileInputStream(f);	
			XSSFWorkbook wb =new XSSFWorkbook(fis);
			XSSFSheet sh= wb.getSheet(Sheet);
			XSSFRow row =sh.getRow(Row);
			XSSFCell cell =row.getCell(Cell);
			cell.setCellValue(Str);
			FileOutputStream fos = new FileOutputStream(f);
			wb.write(fos);
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
		
	}

}
