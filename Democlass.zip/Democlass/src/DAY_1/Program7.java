package DAY_1;

public class Program7 {
	public static void main(String [] args){
		
		double tax=0, sal= 510000;
		if(sal<180000)
		{
			System.out.println("no tax");
		}
	    if(sal>800000)
		{
			sal=sal-800000;
			tax= (sal * 0.3);
			sal= 800000;
		}
		if((sal>500000)&&(sal<=800000))
		{
			sal=sal-500000;
			tax= tax+(sal * 0.2);
			sal=500000;
		}
		
	     if((sal>180000) && (sal<=500000)){
			sal=sal-180000;
			tax= tax+(sal * 0.1);
		}
		
		System.out.println("the tax to be paid is "+tax);
		
	}

}
