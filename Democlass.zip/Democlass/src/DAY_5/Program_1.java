package DAY_5;

import java.util.*;

public class Program_1 {
	public static void main(String[] args) {
		ArrayList<String> Str_al =new ArrayList<String>();
		Str_al.add("PoojaCM");
		Str_al.add("Divya");
		Str_al.add("Anvesh");	
		Str_al.add("Priyanka");
		System.out.println("Before Insertion "+Str_al);
		Str_al.add(3,"Vinod");
		System.out.println("After Insertion "+ Str_al);
		Str_al.remove(1);
		System.out.println("After Deletion "+Str_al);
		Str_al.remove("Vinod");
		System.out.println("After Deletion "+ Str_al);
		for(String s: Str_al)
		{
			System.out.println(s);
		}
	}
}
