package DAY_5;

public class TestRead {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ReadingXLFile obj =new ReadingXLFile();
		String str=obj.ReadExcel("C:\\Users\\BLTuser.BLT0215\\Documents\\Excel\\2.xlsx", "Sheet1", 0, 0);
		System.out.println(str);
	}

}
