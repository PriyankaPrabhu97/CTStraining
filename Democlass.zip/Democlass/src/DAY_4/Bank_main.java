package DAY_4;

public class Bank_main {

	public static void main(String[] args) {
	Bank b;
	b= new Icic();
	System.out.println("Icic roi: "+b.get_roi());
	b= new Hdfc();
	System.out.println("Hdfc roi: "+b.get_roi());
	b=new Bank();
	System.out.println("Bank roi: "+b.get_roi());
	}

}
