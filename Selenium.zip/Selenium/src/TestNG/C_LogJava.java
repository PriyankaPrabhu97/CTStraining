package TestNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class C_LogJava {
	WebDriver dr;
	LogJava jobj;
	
	@BeforeMethod
	public void BM()
	{
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		
		dr = new ChromeDriver();
		dr.get("https://www.saucedemo.com/");
		jobj = new LogJava(dr);				
	}
	
  @Test
  public void LogIn_1()
  {
	  jobj.JLog("standard_user","secret_sauce");
  }
  
  @Test
  public void LogIn_2()
  {
	  jobj.JLog("locked_out_user","secret_sauce");
  }
  
  @AfterMethod
  public void AM()
  {
	  dr.close();
  }
  
}
