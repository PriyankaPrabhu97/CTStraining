package SelFramework;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TextXpaths {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
		dr.findElement(By.xpath("//label[(text()='Email:')]")).click();
		dr.findElement(By.xpath("//label[(text()='Password:')]")).click();
		dr.findElement(By.xpath("//label[(text()='Remember me?')]")).click();
	}

}
