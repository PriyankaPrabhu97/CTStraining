package Library;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Driverfactory {
	
	public static WebDriver launchbrowser(String browser, String url)
	{
		WebDriver dr = null;
		switch(browser)
		{
		case "CHROME":
			System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
			dr = new ChromeDriver();
			break;
			
		case "FIREFOX":
			System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
			dr = new FirefoxDriver();
			break;	
			
	    default:
	    	System.out.println("Supported Browser");
	    	break;
		}
		dr.get("http://demowebshop.tricentis.com/");
		dr.manage().window().maximize();
		dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		return dr;
	}

}
