package DAY_1;

public class Program16 {
	public static void main(String[] args)
    {
int i,n,count=0,temp=0,sum=0;
for(n = 1; n <= 50;n++)
  {
count = 0;
for (i = 2; i<= n/2; i++)
    {
	if(n%i == 0)
	{
	count++;
	break;
	}
    }
if(count==0 && n!=1 )
    {
temp++;
if((temp>5)&&(temp<=10))
               {
System.out.println(n);
sum+=n;
               }
    } 
  }
System.out.println(sum);
   }

}
