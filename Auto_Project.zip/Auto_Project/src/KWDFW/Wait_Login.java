package KWDFW;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Wait_Login {
	WaitTypes wt;
	WebDriver dr;
	public Wait_Login(WebDriver dr)
	{
		this.dr=dr;
	}
	public void login(String uid, String pwd)
	{
		
	    wt = new WaitTypes(dr);
		String a_result;
		
		By by_eid = By.xpath("//input[@class='email']");
		WebElement we_eid = wt.waitForElement(by_eid, 20);
		we_eid.sendKeys(uid);
		
		By by_pwd = By.xpath("//input[@class='password']");
		WebElement we_pwd = wt.waitForElement(by_pwd, 20);
		we_pwd.sendKeys(pwd);
		
		By by_btn = By.xpath("//input[@value='Log in']");
		WebElement we_btn = wt.waitForElement(by_btn, 20);
		we_btn.click();
	}

}
