package DAY_5;

public interface Drawable {
void draw();
}
