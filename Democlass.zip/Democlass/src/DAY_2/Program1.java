package DAY_2;

public class Program1 {

	public static void main(String[] args) {
 int[] marks={98,97,85,45,72,68};
float sum=0; 
 for(int i=0;i<=5;i++)
 {
	 
	 sum+=marks[i];
 }
float avg=sum/6;
System.out.println(avg);
System.out.println(sum);
if(avg>=70)
	System.out.println("FCD");
else if((avg>=60)&&(avg<70))
	System.out.println("FC");
else if((avg>=50)&&(avg<60))
    System.out.println("SC");
else if((avg>=40)&&(avg<50))
    System.out.println("tc");
else
	System.out.println("fail");

	}

}
