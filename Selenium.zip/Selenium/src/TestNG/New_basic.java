package TestNG;

import org.testng.annotations.Test;

public class New_basic {
  @Test
  public void t1() {
	  System.out.println("In t1 : before");
	  
	  try {
		Thread.sleep(5000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  System.out.println("In t1 : after");
  }
  
  @Test
  public void t2() {
	  System.out.println("In t2 : before");
	  
	  try {
		Thread.sleep(5000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  System.out.println("In t2 : after");
  }
}
