package Automate;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class calendar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String exp_mm_yy = "April 2020";
		
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver dr= new ChromeDriver();		
	    dr.get("http://seleniumpractise.blogspot.com/2016/08/how-to-handle-calendar-in-selenium.html");
	    
	    dr.findElement(By.xpath("//input[@id='datepicker']")).click();
	    
	    String cur_mm_yy = dr.findElement(By.xpath("//div[@class='ui-datepicker-title']")).getText();
	    
	    while(!exp_mm_yy.equals(cur_mm_yy))
	    {
	    	dr.findElement(By.xpath("//span[@class='ui-icon ui-icon-circle-triangle-e']")).click();
	    	cur_mm_yy = dr.findElement(By.xpath("//div[@class='ui-datepicker-title']")).getText();
	    }
	    
		
        List<WebElement> all_dates = dr.findElements(By.xpath("//table[@class='ui-datepicker-calendar']//child::td"));
        
        for(WebElement ele:all_dates)
        {
        	String date = ele.getText();
        	if(date.equalsIgnoreCase("20"))
        	{
        		ele.click();
        		break;
        	}
        }
	}

}
