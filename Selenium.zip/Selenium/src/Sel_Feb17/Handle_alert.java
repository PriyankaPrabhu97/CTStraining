package Sel_Feb17;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Handle_alert {
	
	public static void main(String[] args){
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demo.guru99.com/test/delete_customer.php");
		
		dr.findElement(By.xpath("//input[@type='text']")).sendKeys("abdc");
		dr.findElement(By.xpath("//input[@type='submit']")).click();
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Alert a = dr.switchTo().alert();
		String s = a.getText();
		System.out.println(s);
		//a.accept();
		a.dismiss();
		
//		try {
//			Thread.sleep(3000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//		Alert a1 = dr.switchTo().alert();
//		s = a1.getText();
//		a1.accept();
//		System.out.println(s);
	}
	

}
