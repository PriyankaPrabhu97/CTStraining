package DAY_5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadingXLFile
{
	String s;
	
	public String ReadExcel(String Filename, String SheetName, int Row, int Cell )
	{
	File f = new File(Filename);
	try {
		FileInputStream fis =new FileInputStream(f);
		XSSFWorkbook wb =new XSSFWorkbook(fis);
		XSSFSheet sheet =wb.getSheet(SheetName);
		XSSFRow row = sheet.getRow(Row);
		XSSFCell cell = row.getCell(Cell);
		s=cell.getStringCellValue();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	return s;
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
