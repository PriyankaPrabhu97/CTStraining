package Seleniumbasics;

import java.io.FileNotFoundException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;

public class AutoURL {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		WebDriver dr= new ChromeDriver();
		dr.get("http://examples.codecharge.com/Store/Default.php");
		
		String Title=dr.getTitle();
		System.out.println(Title);
		String T="Online Bookstore";
		if(Title.compareTo(T)==0)
			System.out.println("Correct title");
		else
			System.out.println("Wrong title");
		
		dr.findElement(By.xpath("//select[@name='category_id']")).click();
		dr.findElement(By.xpath("//select[@name='category_id']//child::option[3]")).click();
		
		try{
		dr.findElement(By.xpath("//input[@name='DoSearch']")).click();
		}
		catch (WebDriverException e) {
			System.out.println("Exception");
		}
		
		dr.findElement(By.xpath("//a[(text()='Web Database Development')]")).click();
		
		String text=dr.findElement(By.xpath("//h1[(text()='Web Database Development')]")).getText();
        String Txt="Web Database Development";
        if(text.compareTo(Txt)==0)
        	System.out.println("Text displayed");
        else
        	System.out.println("Wrong text");
        
        String price=dr.findElement(By.xpath("//td[@colspan='2']")).getText();
        System.out.println(price);
        
        String pri=price.substring(8,price.length());
       // System.out.println(pri);
        
        dr.findElement(By.xpath("//input[@name='quantity']")).clear();
        dr.findElement(By.xpath("//input[@name='quantity']")).sendKeys("2");
        
        dr.findElement(By.xpath("//input[@name='Insert1']")).click();
        
        String total=dr.findElement(By.xpath("//td[@align='right'][3]")).getText();
        System.out.println("Total: " +total);
        
        String tot=total.substring(1,total.length());
        //System.out.println(tot);
       
        String Quant=dr.findElement(By.xpath("//tr[@class='Row']//child::td/input")).getAttribute("value");
        System.out.println("Quantity: "+Quant);
       
        float P1=Float.parseFloat(pri);
        float P2=Float.parseFloat(tot);
        float Q=Float.parseFloat(Quant);
        
        float TP=P1*Q;
        System.out.println("Total price: "+TP);
        
        if(TP==P2)
        	System.out.println("Correct");
        else
        	System.out.println("wrong");  
        
	}

}
