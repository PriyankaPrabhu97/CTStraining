package DAY_2;

public class Program2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] num={21,22,21,252,241,62,25,24,22};
		int sum=0;
		for(int i=0;i<=8;i+=2)
		{
			if(num[i]%2==1)
			sum+=num[i];
			
		}
		System.out.println(sum);
	}

}
