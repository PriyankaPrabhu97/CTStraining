package DAY_3;

public class Display {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Basic_calc bc=new Basic_calc();
Advanced_calc ac=new Advanced_calc();
bc.add(3, 4);
bc.sub(8, 4);
ac.multiply(3, 4);
	}

}
