package SelFramework;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Registration {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			System.setProperty("webdriver.chrome.driver","chromedriver.exe");
			WebDriver dr= new ChromeDriver();
			dr.get("http://examples.codecharge.com/RegistrationForm/Registration.php");
			
			 dr.findElement(By.xpath("//input[@name='user_login']")).sendKeys("Priya");
			 dr.findElement(By.xpath("//input[@name='user_password']")).sendKeys("Priyanka97");
			 dr.findElement(By.xpath("//input[@name='first_name']")).sendKeys("Priyanka");
			 dr.findElement(By.xpath("//input[@name='last_name']")).sendKeys("Prabhu");
			 dr.findElement(By.xpath("//input[@name='email']")).sendKeys("priyankaprabhu25@gmail.com");
			 dr.findElement(By.xpath("//input[@name='address1']")).sendKeys("Thamirabarani");
			 dr.findElement(By.xpath("//input[@name='address2']")).sendKeys("Canal Road");
			 dr.findElement(By.xpath("//input[@name='address3']")).sendKeys("Thiruvainmyur");
			 dr.findElement(By.xpath("//input[@name='city']")).sendKeys("Chennai");
			 
			 dr.findElement(By.xpath("//select[@name='state_id']//child::option[2]")).click();
			 dr.findElement(By.xpath("//input[@name='zip']")).sendKeys("12345");
			 dr.findElement(By.xpath("//option[@value='112']")).click();
			 dr.findElement(By.xpath("//input[@name='phone_home']")).sendKeys("9964610446");
			 dr.findElement(By.xpath("//input[@name='phone_work']")).sendKeys("9110826984");
			 
			 dr.findElement(By.xpath("//select[@name='language_id']//child::option[3]")).click();
			 dr.findElement(By.xpath("//select[@name='age_id']//child::option[3]")).click();
			 dr.findElement(By.xpath("//select[@name='gender_id']//child::option[2]")).click();
			 dr.findElement(By.xpath("//select[@name='education_id']//child::option[3]")).click();
			 dr.findElement(By.xpath("//select[@name='income_id']//child::option[3]")).click();
			 
			 dr.findElement(By.xpath("//textarea[@name='note']")).sendKeys("I'm the best");
			 dr.findElement(By.xpath("//input[@value='Register']")).click();
			 
			 
	}

}
