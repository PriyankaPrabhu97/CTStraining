package Project1;

import java.util.concurrent.TimeUnit;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Registration_testng extends Registration {
	
	 Registration r;
	  @BeforeClass
	  public void get_data()
	  {
	 System.out.println("before class");
	 get_Test_data();	 
	  }
	  
	  @Test(dataProvider="register")
	  public void register(String fname,String lname,String eid,String pwd,String cpwd,String ex_res)
	  {
	 r=new  Registration();
	String ac_res=r.registration(fname, lname, eid, pwd, cpwd);
	System.out.println("ac_res:"+ac_res);
	System.out.println("ex_res:"+ex_res);
	SoftAssert sa=new SoftAssert();
	sa.assertEquals(ac_res, ex_res);
	sa.assertAll();	 
	  }
	  
	  @DataProvider(name="register")
	  public String[][] provide_data()
	  {
	return testdata;
	  }	 	 
 
}
