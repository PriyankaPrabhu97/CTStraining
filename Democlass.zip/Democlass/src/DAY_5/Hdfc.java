package DAY_5;

public class Hdfc extends Bank {
	public float get_roi()
	{
	return 8.5f;	
	}

}
