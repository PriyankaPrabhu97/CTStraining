package DAY_2;


public class Program8 {
	public static void main(String[] args)
	{
		int[][] m={{75,32,45,23},{32,45,44,93},{52,52,54,12}};	
		int i,j, temp;
	
		for(i=0;i<3;i++)
		{
			for( j=0;j<3;j++)
			{
			
				if(m[i][j]>m[i][j+1])
				{
					temp=m[i][j];
					m[i][j]=m[i][j+1];
					m[i][j+1]=temp;
				}		
			}
			System.out.println(m[i][j]);

		}
		
	}
}
