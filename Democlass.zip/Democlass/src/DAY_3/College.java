package DAY_3;

public class College {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student ramesh =new Student();
		ramesh.java=95;
		ramesh.selenium=85;
		ramesh.calc_avg();
		System.out.println(ramesh.avg);
	}

}
