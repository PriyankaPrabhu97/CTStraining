package PageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AutoHomepage {
	
	WebDriver dr;
	
	@FindBy(xpath="//div[@class='product_label']")
	WebElement protitle;
	
	@FindBy(xpath="//div[@class='inventory_item'][1]//child::div[2]/a//child::div")
	WebElement proname1;
	
	public AutoHomepage(WebDriver dr)
	{
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}
	
	public String display_ProTilte()
	{
		return protitle.getText();
	}
	
	public String display_item1()
	{
		return proname1.getText();
	}

}
