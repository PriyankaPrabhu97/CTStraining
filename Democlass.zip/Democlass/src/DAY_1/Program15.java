package DAY_1;

public class Program15 {
	public static void main(String [] args)
	{
		int i,n1=0,n2=1,n3;
		for(i=0;i<10;i++)
		    {
		        n3=n2+n1;
		System.out.println(n2);
		        n1=n2;
		        n2=n3;  
		    }

	}

}
