package DAY_3;

public class Student {
int id;
String name;
int java;
int selenium;
float avg;
public void calc_avg(){
	avg=(java + selenium)/2f;
}
}
