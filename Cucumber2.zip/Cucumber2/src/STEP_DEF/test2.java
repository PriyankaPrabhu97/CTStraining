package STEP_DEF;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test2 {
	
	WebDriver dr;
	
	@Given("^Browser is launched & search is page displayed$")
	public void browser_is_launched_search_is_page_displayed() throws Throwable {
		System.out.println("browser_is_launched_search_is_page_displayed");
		
		 System.setProperty("webdriver.chrome.driver","chromedriver.exe");
	     dr=new ChromeDriver();
		 dr.get("http://examples.codecharge.com/Store/Default.php");
	   
	}

	@When("^Select Programming from dropdown and click search$")
	public void select_Programming_from_dropdown_and_click_search() throws Throwable {
		System.out.println("select_Programming_from_dropdown_and_click_search");
		dr.findElement(By.xpath("//select[@name='category_id']")).click();
		dr.findElement(By.xpath("//select[@name='category_id']//child::option[2]")).click();
		dr.findElement(By.xpath("//input[@name='DoSearch']")).click();
	    
	}

	@Then("^Displays next page and books$")
	public void displays_next_page_and_books() throws Throwable {
		System.out.println("displays_next_page_and_books");
		String title = dr.getTitle();
		System.out.println(title);
		String web = dr.findElement(By.xpath("//a[@href='ProductDetail.php?product_id=3']")).getText();
		System.out.println(web);

		if(title.equals("SearchResults") && web.equals("Perl and CGI for the World Wide Web"))
		{
			System.out.println("Pass");
		}
		else
		{
			System.out.println("Fail");
		}
	}

}
