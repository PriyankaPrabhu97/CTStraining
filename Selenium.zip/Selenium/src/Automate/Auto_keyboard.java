package Automate;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Auto_keyboard {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		WebDriver dr= new ChromeDriver();		
	    dr.get("http://demowebshop.tricentis.com/accessories");
	    
	      dr.findElement(By.linkText("Log in")).click();
	   WebElement email = dr.findElement(By.xpath("//*[@id='Email']"));
	   email.sendKeys("chennai");
	   
	   Actions kbm = new Actions(dr);
	   
	   kbm
	   .keyDown(email,Keys.SHIFT)
	   .sendKeys(email,"chennai")
	   .keyUp(email,Keys.SHIFT)
	   .build()
	   .perform();
	}

}
