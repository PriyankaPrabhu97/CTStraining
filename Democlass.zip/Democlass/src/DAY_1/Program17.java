package DAY_1;

public class Program17 {
	public static void main(String[] args)
    {
int count=0, n=23184;
while(n>0)
        {

count++;
                n=n/10;
        }
System.out.println(count);
    }


}
