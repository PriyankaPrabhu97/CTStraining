package DAY_2;

public class Program4 {
public static void main(String [] args)
{
	String s ="Chennai", s1="chennai";
	System.out.println("length= "+s.length());
	System.out.println("compare with case "+s.compareTo(s1));
	System.out.println("comparing without case "+s.compareToIgnoreCase(s1));
	System.out.println("substring "+s.substring(0,4));
	System.out.println("the position of e is "+s.indexOf("e",1));
	
}
}
