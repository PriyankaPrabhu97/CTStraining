package KWDFW;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class WaitTestng {
	
	WebDriver dr;
	WaitTypes log_type;
	Wait_Login log_wait;
	
	@BeforeClass
	public void launchBrowser()
	{
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
	}
	
  @Test
  public void f() 
  {
	  log_type = new WaitTypes(dr);
	  log_wait.login("priyankaprabhu25@gmail.com", "priyanka97");
  }
}
