package DAY_3;

public class Zoo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Elephant e1=new Elephant();
		e1.height=7;
		e1.color="Dusky Black";
		e1.Gender='F';
		e1.weight=450;
		e1.LengthOfTrunk= 2;
		e1.LengthOfTusk=1;
		e1.Display_details();
	}

}
