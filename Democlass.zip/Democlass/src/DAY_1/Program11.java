package DAY_1;

public class Program11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,n=0;
	i=0;
	while(i<=30)
		{
			if(i%5==0)
			{
				
			}
			else
			{
				System.out.println(i);
				n+=i;
			}
			i=i+3;
		}
System.out.println(n);
	}

}
