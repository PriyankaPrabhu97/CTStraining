package SelFramework;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Saucedemo {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		WebDriver dr = new ChromeDriver();
		
	     dr.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	     
		dr.get("https://www.saucedemo.com/");

		dr.findElement(By.xpath("//input[@type='text']")).sendKeys("standard_user");

		dr.findElement(By.xpath("//input[@type='password']")).sendKeys("secret_sauce");
		
		

		dr.findElement(By.xpath("//input[@type='submit']")).click();

		String exp_name1=dr.findElement(By.xpath("//a[@id='item_4_title_link']")).getText();
		System.out.println(exp_name1);

		String exp_price1=dr.findElement(By.xpath("//div[@class='inventory_item'][1]//child::div[3]//child::div[1]")).getText();
		//System.out.println(exp_price1);
		String e_p1=exp_price1.substring(1,exp_price1.length());
		System.out.println(e_p1);
		float ep1=Float.parseFloat(e_p1);

		String exp_name2=dr.findElement(By.xpath("//a[@id='item_0_title_link']")).getText();
		System.out.println(exp_name2);

		String exp_price2=dr.findElement(By.xpath("//div[@class='inventory_item'][2]//child::div[3]//child::div[1]")).getText();
		//System.out.println(exp_price2);
		String e_p2=exp_price2.substring(1,exp_price2.length());
		System.out.println(e_p2);
		float ep2=Float.parseFloat(e_p2);
		
        try{
		dr.findElement(By.xpath("//div[@class='inventory_item'][1]//child::div[3]//child::button")).click();
        }
        catch (org.openqa.selenium.NoSuchElementException ee){
        	System.out.println("Product not found");
        }
		dr.findElement(By.xpath("//div[@class='inventory_item'][2]//child::div[3]//child::button")).click();
        
        
		dr.findElement(By.xpath(" //div[@id='shopping_cart_container']//child::a")).click();
		   
		String act_name1=dr.findElement(By.xpath("//a[@id='item_4_title_link']")).getText();
		System.out.println(act_name1);
		   
		String act_price1=dr.findElement(By.xpath("//div[@class='cart_item'][1]//child::div[2]//child::div[2]/div")).getText();
		System.out.println(act_price1);
		float ap1=Float.parseFloat(act_price1);
		   
		String act_name2=dr.findElement(By.xpath("//a[@id='item_0_title_link']")).getText();
		System.out.println(act_name2);

		String act_price2=dr.findElement(By.xpath("//div[@class='cart_item'][2]//child::div[2]//child::div[2]/div")).getText();
		System.out.println(act_price2);
		float ap2=Float.parseFloat(act_price2);

		if((ep1==ap1) && (ep2==ap2))
		{
		 if((exp_name1.compareTo(act_name1)==0))
		 {
		  if((exp_name2.compareTo(act_name2)==0))
		  {
		    System.out.println("PASS");
		  }
		 }
		}
		else
		{
		    System.out.println("FAIL");
		}
	}

}
