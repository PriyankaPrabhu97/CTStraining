package DAY_2;

public class Program9 {

	public static void main(String[] args) {
		int[] a={21,34,91,59,16,44,29,74,49,84};  
		int i,j;
		for( i=0;i<10;i++)
		     {
		for(j=i;j<10;j++)
		         {
		if((a[i]+a[j])==65)
		             {
		System.out.println(a[i]+" and "+a[j]);
					
		}
		         }
		     }
	}
}