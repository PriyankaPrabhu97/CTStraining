package N_tests;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import EXCEL_Util.excel_io_arr;
import N_library.Utilities;
import N_pages.pet_home;
import N_pages.pet_home1;
import N_pages.pet_home2;

public class PetTestng extends excel_io_arr{
	
	WebDriver dr;
	Utilities ut;
	pet_home ph;
	pet_home1 ph1;
	
	String url="http://jpetstore.cfapps.io/catalog";
	
	@BeforeClass
	public void launchBrowser()
	{
		 get_Test_data();
		ut = new Utilities(dr);
	    dr=ut.launchbrowser("CHROME", url);
	    System.out.println("Done");		
	}
	
	@Test
	public void f1()
	{
		ph = new pet_home(dr);
		ph.sign();
		String hometitle = ph.get_title();
		Assert.assertTrue(hometitle.contains("JPet"));
	}
	
	
  @Test(dataProvider="login_data")
  public void f2(String uid, String pwd)
  {
	  System.out.println("uid :"+uid+"pwd :"+pwd);
	  ph1 = new pet_home1(dr);
	  ph1.login(uid, pwd);
	  String rTitle = ph1.get_title();
	  Assert.assertTrue(rTitle.contains("JPet"));	  
  }
//  @AfterClass
//  public void closebrowser()
//  {
//	  dr.close();
//  }
//  
  @DataProvider(name="login_data")
	public String[][] provide_data()
	{
		return testdata;
	}
	
}
