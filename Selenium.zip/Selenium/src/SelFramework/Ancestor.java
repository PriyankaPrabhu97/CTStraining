package SelFramework;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Ancestor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
		dr.findElement(By.xpath("//div[@class='inputs'][1]//child::input"));
		dr.findElement(By.xpath("//div[@class='inputs'][2]//child::input"));
		dr.findElement(By.xpath("//div[@class='buttons']//child::input[@value='Log in']"));
	}

}
