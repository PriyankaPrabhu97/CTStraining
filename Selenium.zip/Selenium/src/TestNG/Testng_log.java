package TestNG;

public class Testng_log {
	
	public void login()
	{
		System.out.println("Login successful");
	}

}
