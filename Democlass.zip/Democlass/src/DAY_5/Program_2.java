package DAY_5;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Program_2 {

	public static void main(String[] args) {
		int i;
		try {
			FileInputStream fis =new FileInputStream("C:\\Users\\BLTuser.BLT0215\\Documents\\Excel\\Airel.txt");
			while((i=fis.read())!=-1)
			{
				System.out.print((char)i);
			}
			fis.close();
			FileOutputStream fos=new FileOutputStream("C:\\Users\\BLTuser.BLT0215\\Documents\\Excel\\Airel.txt");
			byte[] d= "Vinod is innocent and Good Boy".getBytes();
			fos.write(d);
			fos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
