package DAY_2;

public class Program6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          int a=10, b=0,c;
    try
       {
	System.out.println("before");
	c=a/b;
	System.out.println("");
       }
    catch(Exception e)
    {
    System.out.println("catch block");
    }
	}

}
