package DAY_1;

public class Program1 {

	public static void main(String[] args) {
System.out.println("Hello World");

	}

}
