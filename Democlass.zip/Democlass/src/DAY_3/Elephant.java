package DAY_3;

public class Elephant extends Animal 
{
int LengthOfTusk;
int LengthOfTrunk;
public void Display_details()
{
	super.Display();
	System.out.println(" LengthOfTusk: "+LengthOfTusk+" LengthOfTrunk"+LengthOfTrunk);
	
}

}
