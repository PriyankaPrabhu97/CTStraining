package DAY_2;

public class Program11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][] a={{1,2,3,5},{2,3,4,6},{3,4,5,8}},b={{1,2,3,4},{8,4,5,6},{2,5,6,7}};
		int[][] c = new int[3][4];
		int i,j;
		for(i=0;i<3;i++)
		      {
		for(j=0;j<4;j++)
		          {
		c[i][j]=a[i][j]+b[i][j];


		System.out.print(c[i][j]);
		System.out.print(" ");
		          } 
		System.out.println("");
		      }

	}

}
