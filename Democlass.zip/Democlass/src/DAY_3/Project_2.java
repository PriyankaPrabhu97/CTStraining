package DAY_3;



public class Project_2 {

	public static void main(String[] args)
	{
		String S="MalayaLaM";
		int i=0, j=S.length()-1,k=0;
		while(k<S.length())
		if(S.charAt(i)==S.charAt(j))
		{
			System.out.println("palindrome");
			j--;
			i++;
			k++;
			break;
		}
		else
		{
			System.out.println("Not palindrome");
		break;
		}
	}

}
