package DAY_5;

public class Rectangle implements Drawable {
	public void draw()
	{
		System.out.println("Draw Rectangle");
	}

}
