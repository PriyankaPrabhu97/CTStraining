package DAY_5;
import java.util.Scanner;


public class Details {

		static String std[][]= {{"11","girish"},{"12","remesh"},{"13","umesh"},{"14","selva"}};
		static int marks[][]= {{11,95,80,0},{12,76,79,0},{13,89,91,0},{14,85,89,0}};

		public int search(String sid) //searches std id in marks array
		{
		int index = 0;
		
		int id=Integer.parseInt(sid);
		for(int i=0; i<=4; i++)
		{
		if(id==marks[i][0])
		{
		index=i;
		break;
		}
		}
	
		return index;
		}

		public int cal_avg(int ind)
		{
		int avg;
		avg=(marks[ind][1] + marks[ind][2])/2;
		return avg;
		}

		public String getname(String stdid)
		{
		String n = null;
		for(int j=0;j<=4;j++)
		{
		if(stdid.equals(std[j][0]))
		{
		n=std[j][1];
		//System.out.println(n);
		break;
		}
		}
		return n;
		}
		public static void main(String[] args) {
		//System.out.println("Enter the Id");
		//Scanner sid= new Scanner(System.in);
			
		Details mar =new Details();

		System.out.println("Id "+"Name "+"Avg");


		String name=mar.getname("11");
		int j=mar.search("11");
		int avge=mar.cal_avg(j);
		
		System.out.println(marks[j][0]+" "+name+" " + avge);
		}

}
