package DAY_4;

public class Student {
int id;
String name;
int java;
int selenium;
float avg;
public Student(int selenium, int java ){
	System.out.println("obj created");
	this.java=java;
	this.selenium =selenium;
}
public void calc_avg(){
	avg=(java + selenium)/2f;
}
}
