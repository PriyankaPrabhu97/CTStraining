package Testng_DataD;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class dataprovider_login {
	
	dataprovider_loginJava dobj = new 	dataprovider_loginJava();
	
  @Test(dataProvider="login_data")
  public void test1(String eid, String pwd, String Exp_eid) 
  {
	  String a_eid = dobj.Dlogin(eid, pwd);
	  SoftAssert sa = new SoftAssert();
	  sa.assertEquals(a_eid, Exp_eid);
	  sa.assertAll();
  }
  
  @DataProvider(name="login_data")
  public String[][] provide_data()
  {
	  String[][] data = {
			                {"priyankaprabhu25@gmail.com","priyanka97","priyankaprabhu25@gmail.com"},
			                {"priyankaprabhu25@gmail.com","priyanka97","priyankaprabhu2@gmail.com"}
	                    };
	  return data;
  }
}
