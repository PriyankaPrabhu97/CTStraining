package Tests;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import Library.Utilities;
import Pages.home_page;
import Pages.next_page;


public class Chrome_Test {
String url="http://examples.codecharge.com/Store/Default.php";

Utilities obj_util;
home_page obj_home;
next_page obj_next;
WebDriver dr;


 @BeforeClass
 public void beforeClass()
 {
 obj_util =new Utilities(dr);
 dr=obj_util.LaunchBrowser("CHROME", url);
 }

 
 @Test(priority=0)
 public void home_page_test()
 {
 SoftAssert sa= new SoftAssert();
 obj_home = new  home_page(dr);
 obj_home.do_search();
 String act_title= obj_home.get_title();
 sa.assertTrue(act_title.contains("Bookstore"));
 }
 
  @Test(priority=1)
  public void next_page_test()
  {
 SoftAssert sa= new SoftAssert();
 obj_next = new  next_page(dr);
 String act_name=obj_next.book_name();
 sa.assertTrue(act_name.contains("World Wide"));
  String act_title= obj_next.get_title();
 sa.assertTrue(act_title.contains("Search"));
 sa.assertAll();
 
  }
 
}

