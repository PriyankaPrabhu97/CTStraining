package Seleniumbasics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Method {
	
	public void login(String eid, String pwd){
		
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		WebDriver dr= new ChromeDriver();
		
	    dr.get("http://demowebshop.tricentis.com");
	    
	    dr.findElement(By.linkText("Log in")).click();
	    dr.findElement(By.id("Email")).sendKeys(eid);
	    dr.findElement(By.id("Password")).sendKeys(pwd);
	    dr.findElement(By.xpath("//input[@value='Log in']")).click();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Method L=new Method();
      L.login("priyankaprabhu25@gmail.com", "priyanka97");
	}

}
