package DAY_3;

import java.util.Scanner;

public class Program_3
{
	public static void main(String[] args)
	{
		String[][] str = {{"1","vinod"},{"2","Divya"}, {"3","Anvesh"},{"4","Priyanka"}, {"5","PoojaCM"}};
		 String Empid;
		 int i,j;
		 System.out.println("Eneter the empid");
		 Scanner in = new Scanner(System.in);
		 Empid=in.next();
			for(i=0;i<5;i++)
			{
				
	
				
				int k= str[i][0].compareTo(Empid);
				if(k==0)
				{
					System.out.println(str[i][1]);
				}
			
				}
				 
		
	}
}
