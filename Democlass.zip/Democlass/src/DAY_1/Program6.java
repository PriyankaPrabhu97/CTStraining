package DAY_1;

public class Program6 {

	public static void main(String[] args) {
		int a=15,b=10,c=4;
		if(a<b)
		{
			if (a<c)
			System.out.println("smallest number is " +a);
			else
				System.out.println("smallest is "+c);
		}
		else if(b<c)
		{
			System.out.println("smallest is "+b);
		}
		else
			System.out.println("smallest is "+c);
			
	

	}

}
