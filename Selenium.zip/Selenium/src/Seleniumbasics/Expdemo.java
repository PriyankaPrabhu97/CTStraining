package Seleniumbasics;

import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Expdemo {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		WebDriver dr= new ChromeDriver();
		
	    dr.get("http://demowebshop.tricentis.com/accessories");
	    
	    String xp="/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input1",
	    	   xp1="/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input";
	     WebElement we;
	     WebDriverWait wt=new WebDriverWait(dr,20);
	     we=wt.until(ExpectedConditions.elementToBeClickable(By.xpath(xp)));
	     we.click();
	    
	    dr.findElement(By.linkText("Log in")).click();
	    dr.findElement(By.id("Email")).sendKeys("priyankaprabhu25@gmail.com");
	    dr.findElement(By.id("Password")).sendKeys("9110826984");
	    dr.findElement(By.xpath("//input[@value='Log in']")).click();
	    
	    
}
}