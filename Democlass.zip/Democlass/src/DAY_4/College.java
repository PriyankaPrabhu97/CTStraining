package DAY_4;

public class College {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student ramesh =new Student(95,85);
		ramesh.calc_avg();
		System.out.println(ramesh.avg);
	}

}
