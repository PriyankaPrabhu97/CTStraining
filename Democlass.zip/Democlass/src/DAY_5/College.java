package DAY_5;

import java.util.ArrayList;

public class College {

	ArrayList<Student> std_al =new ArrayList<Student>();
	public void create(){
		   Student s1= new Student("Divya",89,91,90);
		    Student s2= new Student("Anvesh",86,98,97);
		    Student s3= new Student("Vinod",86,92,89);
		    std_al.add(s1);
		    std_al.add(s2);
		    std_al.add(s3);
		    
	}
	public void Display()
	{
		for(Student s:std_al)
			
		{
		System.out.println("Name: "+s.name
				           +" Selenium marks: "+s.selenium
				           +" Java marks: "+s.java
				           +" avg: "+s.avg);	
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		College obj =new College();
		obj.create();
		obj.Display();
	}

}
