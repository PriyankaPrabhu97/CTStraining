package N_pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import N_library.Utilities;

public class pet_home1 {

	WebDriver dr;
	Utilities wt;
		
	public pet_home1(WebDriver dr)
	{
		this.dr=dr;
		wt= new Utilities(dr);
	}
	
//	public void sign_in()
//	{
//		 By reg_now = By.xpath("//div[@id='Catalog']/a");
//		 WebElement we_reg_now=wt.waitForElement(reg_now,20);
//		 we_reg_now.click();
//	}
	
	public void login(String ur, String pwd)
	{
		 By reg_now = By.xpath("//input[@name='username']");
		 WebElement we_reg_now=wt.waitForElement(reg_now,20);
		 we_reg_now.sendKeys(ur);
		 
		 By password = By.xpath("//input[@name='password']");
		 WebElement we_reg=wt.waitForElement(password,20);
		 we_reg.sendKeys(pwd);
		
		 
		 By log = By.xpath("//input[@id='login']");
		 WebElement we_log=wt.waitForElement(log,20);
		 we_log.click();	
		 
		 wt.getScreenshot();
	}
	
	
	public String get_title()
	{
		return dr.getTitle();
	}
}
