package DAY_3;

public class Advanced_calc {
	public void multiply(int a, int b)
	{
		int c ;
		c=a*b;
		System.out.println(c);

}
}