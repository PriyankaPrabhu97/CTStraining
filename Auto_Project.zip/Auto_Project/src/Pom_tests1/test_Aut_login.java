package Pom_tests1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Pom_Pages1.AutHomeJava;
import Pom_Pages1.AutLoginJava;

public class test_Aut_login {
	
	WebDriver dr;
	AutLoginJava loginpage;
	AutHomeJava homepage;
	@BeforeClass
	public void launchBrowser()
	{
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
	}
  @Test(priority=0)
  public void test_login_page()
  {
	  loginpage = new AutLoginJava(dr);
	  String loginpage_title = loginpage.get_title();
	  Assert.assertTrue(loginpage_title.contains("Shop"));
  }
  @Test(priority=1)
  public void test_home_page()
  {
	  loginpage.do_login("priyankaprabhu25@gmail.com", "priyanka97");
	  homepage = new AutHomeJava(dr);
	  String actual_eid = homepage.get_displayed_eid();
	  Assert.assertTrue(actual_eid.contains("priyankaprabhu25@gmail.com"));
  }
}
