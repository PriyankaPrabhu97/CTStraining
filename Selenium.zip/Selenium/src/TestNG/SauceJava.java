package TestNG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SauceJava {
	
    WebDriver dr;
    String itemN,itemP;
    String exP;
    float Ex_P;
	
	public void SauLog(String eid, String pwd)
	{
		dr.findElement(By.xpath("//input[@type='text']")).sendKeys(eid);
		dr.findElement(By.xpath("//input[@type='password']")).sendKeys(pwd);
		dr.findElement(By.xpath("//input[@type='submit']")).click();
	}
	
	public SauceJava(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public void add_product(int n)
	{
		itemN=dr.findElement(By.xpath("//div[@class='inventory_item']["+n+"]//child::div[2]/a//child::div")).getText();
	    itemP=dr.findElement(By.xpath("//div[@class='inventory_item']["+n+"]//child::div[3]//div")).getText();
		 System.out.println("Exp name: "+itemN);
		 System.out.println("Exp price: "+itemP);
		 
		 exP=itemP.substring(1,itemP.length());
		 //System.out.println(exP);
		 
		 try{     			
			 Ex_P=Float.parseFloat(exP);
			}catch(java.lang.NumberFormatException e){
				  System.out.println("Exc");
			  }
		 
	    dr.findElement(By.xpath("//div[@class='inventory_item']["+n+"]//child::div[3]/button")).click();
		       	 		  
	}
	
	public void verify()
	{
		dr.findElement(By.xpath("//div[@id='shopping_cart_container']//child::a")).click();
		
		String AitemN = dr.findElement(By.xpath("//div[@class='inventory_item_name'][1]")).getText();
		String AitemP = dr.findElement(By.xpath("//div[@class='inventory_item_price'][1]")).getText();
		System.out.println("Act name: "+AitemN);
		System.out.println("Act name: "+AitemP);
			
		float Ac_P=Float.parseFloat(AitemP);
				 
		 if(Ac_P==Ex_P)
		 {
			 if(AitemN.compareTo(itemN)==0)
			 {
				 System.out.println("Pass");
			 }
			 else
			 {
				 System.out.println("Fail");
			 }
		 }
		
	}
	 
	public void add_info()
	{
		dr.findElement(By.xpath("//div[@class='cart_footer']/a[2]")).click();
		
		dr.findElement(By.xpath("//input[@id='first-name']")).sendKeys("Priya");
		dr.findElement(By.xpath("//input[@id='last-name']")).sendKeys("CKM");
		dr.findElement(By.xpath("//input[@id='postal-code']")).sendKeys("4567");
		dr.findElement(By.xpath("//div[@class='checkout_buttons']/input")).click();	
	}

}
