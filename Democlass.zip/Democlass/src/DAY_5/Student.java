package DAY_5;

public class Student {
int id;
String name;
int java;
int selenium;
float avg;
public Student(String name, int selenium, int java, int avg ){

	this.java=java;
	this.selenium =selenium;
	this.name =name;
	this.avg=avg;
}
public void calc_avg(){
	avg=(java + selenium)/2f;
}
}
