package DAY_3;

public class Basic_calc {
	public void add(int a, int b)
	{
		int c ;
		c=a+b;
		System.out.println(c);
	}
	public void sub(int a, int b)
	{
		int c ;
		c=a-b;
		System.out.println(c);

}
}