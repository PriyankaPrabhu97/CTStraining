package DAY_4;

public class Program_2 {
	public void add(int x ,int y)
	{
		int z;
		z=x+y;
		System.out.println("two parameters"+"\n Sum is "+z);
	}

	public void add(int x ,int y, int a)
	{
		int z;
		z=x+y;
		System.out.println("three parameters"+"\n Sum is "+z);
	}
	public static void main(String[] args) {
		Program_2 obj =new Program_2();
		obj.add(5, 6);
		obj.add(2, 12, 22);
	}

}
