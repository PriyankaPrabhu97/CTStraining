package DAY_1;

public class Program10 {

public static void main(String[] args) {
		// TODO Auto-generated method stub
		int r,sum=0,n=1235;
		while(n>0)
		{
			r=n%10;
			sum+=r;
			n=n/10;			
		}
    System.out.println(sum);
	}

}
