package DAY_3;

public class Animal {
 int height;
 int weight;
 String color;
 char Gender;
 public void Display()
 {
	 System.out.println("height: " +height+ " weight: "+weight+ " color: "+color+ " Gender: "+Gender);
 }
}
