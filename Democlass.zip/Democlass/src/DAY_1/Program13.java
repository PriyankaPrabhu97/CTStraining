package DAY_1;

public class Program13 {
	public static void main(String [] args)
	{
		int i,n=0;
	
i=21;
while(i<=75)
	{
		
		{
			System.out.println(i);
			n+=i;
		}
		i=i+7;
	}
System.out.println(n);

}
}