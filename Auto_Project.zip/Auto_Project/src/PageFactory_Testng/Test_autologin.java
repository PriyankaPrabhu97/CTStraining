package PageFactory_Testng;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import PageFactory.AutoHomepage;
import PageFactory.AutoLogin;
import Pom_Pages1.AutHomeJava;
import Pom_Pages1.AutLoginJava;

public class Test_autologin {
	
	WebDriver dr;
	AutoLogin loginpage;
	AutoHomepage homepage;
	@BeforeClass
	public void launchBrowser()
	{
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		dr = new ChromeDriver();
		dr.get("https://www.saucedemo.com/");
	}
	
	@Test(priority=0)
	 public void test_login_page()
	  {
		  loginpage = new AutoLogin(dr);
		  String loginpage_title = loginpage.get_title();
		  Assert.assertTrue(loginpage_title.contains("Swag"));
	  }
	
	@Test(priority=1)
	 public void test_home_page()
	  {
		  loginpage.do_login("standard_user", "secret_sauce");
		  homepage = new AutoHomepage(dr);
		  String actual_title = homepage.display_ProTilte();
		  Assert.assertTrue(actual_title.contains("Products"));
	  }
  @Test(priority=2)
  public void get_itenName() 
  {
	  String actual_ProName = homepage.display_item1();
	  Assert.assertTrue(actual_ProName.contains("Sauce Labs Backpack"));
	  
  }
}
