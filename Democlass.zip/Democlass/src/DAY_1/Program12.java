package DAY_1;

public class Program12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int r,sum=0,n=59138;
		while(n>0)
		{
			r=n%10;
			if(r>5)
			{
			sum+=r;
			}
			n=n/10;			
		}
    System.out.println(sum);
	}

}
