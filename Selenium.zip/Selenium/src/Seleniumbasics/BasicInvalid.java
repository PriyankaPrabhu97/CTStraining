package Seleniumbasics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BasicInvalid {
	
public String InVlogin(String eid, String pwd){
		
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		WebDriver dr= new ChromeDriver();
		
	    dr.get("http://demowebshop.tricentis.com");
	    
	    dr.findElement(By.linkText("Log in")).click();
	    dr.findElement(By.id("Email")).sendKeys(eid);
	    dr.findElement(By.id("Password")).sendKeys(pwd);
	    dr.findElement(By.xpath("//input[@value='Log in']")).click();
	    String errM = dr.findElement(By.xpath("//div[@class='validation-summary-errors']")).getText();
	    return errM;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String Eml="priyankaprabhu25@gmail.com", pawd="priyanka97";
		BasicInvalid vv = new BasicInvalid();
		String in= vv.InVlogin(Eml, pawd);

	}

}
