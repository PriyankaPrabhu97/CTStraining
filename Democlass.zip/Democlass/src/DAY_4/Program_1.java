package DAY_4;

import java.util.Scanner;

public class Program_1 {
	String[][] std = {{"1","vinod"},{"2","Divya"}, {"3","Anvesh"},{"4","Priyanka"}, {"5","PoojaCM"}};
    static int[][] marks={{5,95,97,0},{2,56,93,0},{3,47,85,0},{4,98,95,0},{12,65,58,0}};
    static int i,ID;

    public int avg(int x, int y)
    {
    	int z; z=(x+y)/2;
    	return z;
    }
   
    public void search()
    {
    	for(i=0;i<5;i++)
    	{
    	int l=Integer.parseInt(std[i][0]);
    	if(l==marks[i][0])
    	{
    		System.out.println("id "+(ID)+" name "+std[ID-1][1]+" avg "+marks[ID-1][3]);
    		break;
    	}
    	}
    }
    public void SearchByID()
	{
    	System.out.println("enter the ID"); 
    	Scanner input =new Scanner(System.in);
	    ID=input.nextInt();
	    for(i=0;i<5;i++)
	    {
	    if(ID==marks[i][0])
	    {
	    int y=this.avg(marks[i][1], marks[i][2]);
	    marks[ID-1][3]=y;
	    }
	    }
	    this.search();
	}
	public static void main(String[] args){
	
	Program_1 Obj =new Program_1();
	Obj.SearchByID();
}
}