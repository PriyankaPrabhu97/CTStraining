package Seleniumbasics;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Webele3 {
	static String s1;
	String s2,s3;
	public void extract()
	{
		   int p= s1.indexOf(":",0);
		   int p1= s1.indexOf("A",0);
		   s2= s1.substring(p+2,p1-1);
		   System.out.println(s2);
		   int p2=s1.indexOf(":",p1);
		   s3= s1.substring(p2+2);
		   System.out.println(s3);   
	}
	public void compare()
	{
		String s="Female", ss="5 - 15";
		if((s.compareTo(s2)==0) && (s3.compareTo(ss)==0))
			System.out.println("Pass");
		else
			System.out.println("Fail");
	}
	 

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
       WebDriver dr = new ChromeDriver();
       dr.get("https://www.seleniumeasy.com/test/basic-radiobutton-demo.html");
       
      // List rb = dr.findElements(By.name("optradio"));
       //((WebElement) rb.get(1)).click(); //type-casting, rb is list which is made as web-element
	
       List rb = dr.findElements(By.name("gender"));
	   ((WebElement) rb.get(0)).click();
	   
	   List rb1 = dr.findElements(By.name("ageGroup"));
	   ((WebElement) rb1.get(1)).click();
	   
	   dr.findElement(By.xpath("//*[@id='easycont']/div/div[2]/div[2]/div[2]/button")).click();
	   //String s= dr.findElement(By.xpath("//*[@id='easycont']/div/div[2]/div[2]/div[2]/button")).getText();
	   s1 = dr.findElement(By.xpath("//*[@id='easycont']/div/div[2]/div[2]/div[2]/p[2]")).getText();
	   System.out.println(s1);
	  
	   Webele3 obj1 = new Webele3();
	   obj1.extract();
	}
	
}
