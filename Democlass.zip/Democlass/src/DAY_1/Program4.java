package DAY_1;

public class Program4 {
	public static void main(String[] args){
		int a=10, b=20;
		if(a>b)
		{
			System.out.println(a+" is greter than "+b);
		}
		else if(a==b)
		{
			System.out.println(a+" equal than "+b);
		}
		else
			System.out.println(a+" is less than "+b);
	}
}
