package TestNG;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Call_Log {
	
	Testng_log obj;
	
	@BeforeMethod
	public void beforeMethod()
	{
		obj = new Testng_log();
	}
	
  @Test
  public void f()
  {  
	  obj.login();
  }
}
