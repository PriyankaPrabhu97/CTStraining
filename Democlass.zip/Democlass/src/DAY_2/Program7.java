package DAY_2;

public class Program7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10, b=0, c;
		int[] m={1,2,3};
		try
		{
			c=a/b;
			System.out.println(m[5]);
		}
		catch(ArithmeticException ae)
		{
			System.out.println("ArthmaticException");
		}
		catch(ArrayIndexOutOfBoundsException aie)
		{
			System.out.println("ArrayIndexOutOfBoundsException");
		}

	}

}
